import { fork } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  decodePackage, encodePackage, jsonValue, validateDeckLayout, validateOpenCodeSnapshot,
} from '@macromaxx/plugin-sdk/contracts';
import { validateOutput } from './output.js';

export class PluginProcess {
  constructor(pkg) {
    this.pkg = decodePackage(encodePackage(pkg.manifest, pkg.code));
    this.queue = Promise.resolve();
    this.sequence = 0;
  }
  dispatch(event, payload = {}, signal) {
    const run = this.queue.then(() => this.request(event, payload, signal));
    this.queue = run.catch(() => {});
    return run;
  }
  request(event, payload, signal) {
    if (this.closed) return Promise.reject(new Error('Plugin is closed.'));
    if (signal?.aborted) return Promise.reject(new Error('Canceled.'));
    if (!['activate', 'deactivate', 'execute', 'keyDown', 'keyUp', 'deckRender'].includes(event))
      return Promise.reject(new Error('Invalid event.'));
    const permissions = this.pkg.manifest.permissions;
    const { deck, opencode, keyAction, ...base } = payload;
    const safePayload = jsonValue({
      ...base,
      ...(deck && permissions.includes('deck:write') && ['execute', 'deckRender'].includes(event)
        ? { deck: validateDeckLayout(deck) } : {}),
      ...(opencode && permissions.includes('opencode:sessions:read') && ['execute', 'deckRender'].includes(event)
        ? { opencode: validateOpenCodeSnapshot(opencode) } : {}),
      ...(event === 'deckRender' && typeof keyAction === 'string' && /^[a-z][a-z0-9-]{0,47}$/.test(keyAction)
        ? { keyAction } : {}),
    }, 128 * 1024);
    if (event === 'deckRender' && !safePayload.deck)
      return Promise.reject(new Error('Deck render requires an authorized layout.'));
    if (!this.child) {
      const env = { ELECTRON_RUN_AS_NODE: '1' };
      if (process.platform === 'win32') env.SystemRoot = process.env.SystemRoot;
      const workerFile = fileURLToPath(new URL('./worker.js', import.meta.url)).replace(
        /app\.asar([/\\])/,
        'app.asar.unpacked$1',
      );
      this.child = fork(workerFile, [], {
        env,
        execArgv: ['--max-old-space-size=128'],
        stdio: ['ignore', 'ignore', 'ignore', 'ipc'],
        windowsHide: true,
      });
    }
    const child = this.child,
      id = ++this.sequence;
    return new Promise((resolve, reject) => {
      let finished = false;
      const done = (error, value) => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        signal?.removeEventListener('abort', abort);
        child.off('message', message);
        child.off('error', failure);
        child.off('exit', exit);
        this.pending = null;
        if (error) {
          child.kill('SIGKILL');
          if (this.child === child) this.child = null;
          reject(error);
        } else resolve(value);
      };
      const abort = () => done(new Error('Canceled.'));
      const failure = (error) => done(error);
      const exit = () => done(new Error('Plugin process exited.'));
      const message = (msg) => {
        if (msg?.id !== id) return;
        try {
          msg.error
            ? done(new Error(String(msg.error)))
            : done(null, validateOutput(msg.result, permissions, event, safePayload.deck));
        } catch (error) {
          done(error);
        }
      };
      const timer = setTimeout(() => done(new Error('Plugin timeout (5 seconds).')), 5000);
      this.pending = abort;
      signal?.addEventListener('abort', abort, { once: true });
      child.on('message', message);
      child.once('error', failure);
      child.once('exit', exit);
      child.send({ id, pkg: this.pkg, event, payload: safePayload }, (error) => {
        if (error) done(error);
      });
    });
  }
  close() {
    this.closed = true;
    this.pending?.();
    this.child?.kill('SIGKILL');
    this.child = null;
  }
}
