import fs from 'node:fs/promises';
import path from 'node:path';
import { Readable } from 'node:stream';
import { Updater, BaseFetcher } from 'tuf-js';
// Pinned tuf-js 6.0.2: required for the upstream client's root-rotation 404 handling.
import { DownloadHTTPError } from 'tuf-js/dist/error.js';
import { validateCatalog, MAX_PACKAGE_BYTES } from '@macromaxx/plugin-sdk/contracts';

function endpoint(value, allowLoopback) {
  const url = new URL(value);
  if (
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    (url.protocol !== 'https:' &&
      !(allowLoopback && url.protocol === 'http:' && ['127.0.0.1', '[::1]'].includes(url.hostname)))
  )
    throw new Error('Registry endpoints must use HTTPS without credentials.');
  if (!url.pathname.endsWith('/')) throw new Error('Endpoint must end in /.');
  return url;
}
class RestrictedFetcher extends BaseFetcher {
  constructor(urls) {
    super();
    this.urls = urls;
  }
  async fetch(value) {
    const url = new URL(value);
    if (
      !this.urls.some(
        (base) => url.origin === base.origin && url.pathname.startsWith(base.pathname),
      )
    )
      throw new Error('Unexpected registry URL.');
    const deadline = Date.now() + 30000;
    for (let attempt = 0; attempt < 3; attempt++) {
      const response = await fetch(url, { redirect: 'error', signal: AbortSignal.timeout(Math.max(1, Math.min(15000, deadline - Date.now()))) });
      if (response.ok && response.body) return response.body;
      await response.body?.cancel();
      const error = new DownloadHTTPError(`Registry HTTP ${response.status} at ${url.pathname}`, response.status);
      const retryAfter = response.headers.get('retry-after');
      let delay = 100 * (attempt + 1);
      if (retryAfter !== null) {
        const numeric = /^\d+$/.test(retryAfter);
        const seconds = numeric ? Number(retryAfter) : (Date.parse(retryAfter) - Date.now()) / 1000;
        if (numeric && !Number.isFinite(seconds)) throw error;
        if (Number.isFinite(seconds)) delay = Math.max(0, seconds * 1000);
      }
      if (![429, 502, 503, 504].includes(response.status) || attempt === 2 || delay > 2000 || Date.now() + delay >= deadline)
        throw error;
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  async downloadBytes(url, maxLength) {
    const reader = (await this.fetch(url)).getReader(),
      chunks = [];
    let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > Math.min(maxLength, 5 * 1024 * 1024))
          throw new Error('Download quota exceeded.');
        chunks.push(Buffer.from(value));
      }
      return Buffer.concat(chunks);
    } finally {
      await reader.cancel().catch(() => {});
      reader.releaseLock();
    }
  }
}

export class TrustedRegistry {
  constructor({ directory, metadataUrl, targetsUrl, root, allowLoopback = false }) {
    this.directory = directory;
    this.metadataUrl = endpoint(metadataUrl, allowLoopback).href;
    this.targetsUrl = endpoint(targetsUrl, allowLoopback).href;
    if (root?.signed?._type !== 'root') throw new Error('Pinned TUF root required.');
    this.root = root;
    this.fetcher = new RestrictedFetcher([new URL(this.metadataUrl), new URL(this.targetsUrl)]);
  }
  async refresh() {
    await fs.mkdir(this.directory, { recursive: true, mode: 0o700 });
    try {
      await fs.writeFile(path.join(this.directory, 'root.json'), JSON.stringify(this.root), {
        flag: 'wx',
        mode: 0o600,
      });
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
    }
    this.updater = new Updater({
      metadataDir: this.directory,
      metadataBaseUrl: this.metadataUrl,
      targetBaseUrl: this.targetsUrl,
      fetcher: this.fetcher,
      config: {
        maxDelegations: 0,
        maxRootRotations: 32,
        rootMaxLength: 512 * 1024,
        timestampMaxLength: 64 * 1024,
        snapshotMaxLength: 512 * 1024,
        targetsMaxLength: 5 * 1024 * 1024,
      },
    });
    await this.updater.refresh();
    // Fall back only when verified metadata has no extended target, not when
    // an advertised target cannot be downloaded or verified.
    const name = await this.updater.getTargetInfo('catalog-v2.json') ? 'catalog-v2.json' : 'catalog.json';
    const bytes = await this.target(name, 5 * 1024 * 1024);
    const catalog = validateCatalog(JSON.parse(bytes.toString('utf8')));
    const expirations = await Promise.all(
      ['root', 'timestamp', 'snapshot', 'targets'].map(async (role) =>
        Date.parse(
          JSON.parse(await fs.readFile(path.join(this.directory, role + '.json'))).signed.expires,
        ),
      ),
    );
    this.validUntil = Math.min(Date.parse(catalog.expires), ...expirations);
    if (this.validUntil <= Date.now()) throw new Error('Registry metadata expired.');
    return catalog;
  }
  async target(name, maxLength) {
    const info = await this.updater.getTargetInfo(name);
    if (!info || info.length > maxLength || !/^[a-f0-9]{64}$/.test(info.hashes.sha256))
      throw new Error('Missing or oversized authenticated target.');
    const physical = path.posix.join(
      path.posix.dirname(name),
      info.hashes.sha256 + '.' + path.posix.basename(name),
    );
    const bytes = await this.fetcher.downloadBytes(
      new URL(physical, this.targetsUrl).href,
      info.length,
    );
    await info.verify(Readable.from(bytes));
    return bytes;
  }
  async download(release) {
    if (!this.updater || this.validUntil <= Date.now())
      throw new Error('Refresh trusted registry before downloading.');
    return this.target(`artifacts/sha256/${release.sha256}.mmxp`, MAX_PACKAGE_BYTES);
  }
}
