import { exactKeys, jsonValue } from '@macromaxx/plugin-sdk/contracts';

export function validateOutput(value, permissions) {
  exactKeys(value, ['display', 'settings', 'messages'], ['messages']);
  if (
    !Array.isArray(value.messages) ||
    value.messages.length > 20 ||
    value.messages.some((m) => typeof m !== 'string' || m.length > 1000)
  )
    throw new Error('Log quota exceeded.');
  if (value.display !== undefined) {
    if (!permissions.includes('display:write')) throw new Error('Missing display permission.');
    exactKeys(value.display, ['label', 'color'], []);
    if (
      value.display.label !== undefined &&
      (typeof value.display.label !== 'string' || value.display.label.length > 80)
    )
      throw new Error('Invalid display label.');
    if (value.display.color !== undefined && !/^#[0-9a-f]{6}$/i.test(value.display.color))
      throw new Error('Invalid display color.');
  }
  if (value.settings !== undefined) {
    if (!permissions.includes('settings:write')) throw new Error('Missing settings permission.');
    if (!value.settings || Array.isArray(value.settings) || typeof value.settings !== 'object')
      throw new Error('Settings must be an object.');
    jsonValue(value.settings);
  }
  return jsonValue(value, 70 * 1024);
}
