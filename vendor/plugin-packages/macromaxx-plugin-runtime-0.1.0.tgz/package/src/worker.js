import { Guest } from './guest.js';
import { decodePackage, encodePackage } from '@macromaxx/plugin-sdk/contracts';
let guest,
  queue = Promise.resolve();
process.on('message', (message) => {
  queue = queue.then(async () => {
    try {
      if (!guest)
        guest = await Guest.create(
          decodePackage(encodePackage(message.pkg.manifest, message.pkg.code)),
        );
      const result = guest.dispatch(message.event, message.payload);
      process.send?.({ id: message.id, result });
    } catch (error) {
      process.send?.({ id: message.id, error: String(error.message).slice(0, 1000) });
    }
  });
});
process.on('disconnect', () => process.exit(0));
