import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import semver from 'semver';
import { decodePackage, jsonValue, MAX_PACKAGE_BYTES } from '@macromaxx/plugin-sdk/contracts';
import { PluginProcess } from './process.js';

const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const sameRelease = (release, record) =>
  release.manifest.id === record.id &&
  release.manifest.version === record.version &&
  release.sha256 === record.sha256;

export class PluginStore {
  constructor({
    directory,
    registry,
    appVersion,
    platform = process.platform,
    onDisplay = () => {},
    changed = () => {},
  }) {
    Object.assign(this, { directory, registry, appVersion, platform, onDisplay, changed });
    this.state = { version: 1, installed: {} };
    this.workers = new Map();
    this.probes = new Map();
    this.installing = new Set();
    this.errors = new Map();
    this.generations = new Map();
    this.installGenerations = new Map();
    this.autoUpdateIntent = new Map();
    this.enableIntent = new Map();
    this.queue = Promise.resolve();
  }
  mutation(fn) {
    const run = this.queue.then(() => {
      if (this.closed) throw new Error('Store closed.');
      return fn();
    });
    this.queue = run.catch(() => {});
    return run;
  }
  async init() {
    await fs.mkdir(path.join(this.directory, 'objects'), { recursive: true, mode: 0o700 });
    const load = async (file) => {
      if ((await fs.stat(file)).size > 5 * 1024 * 1024)
        throw new Error('Store state quota exceeded.');
      const state = JSON.parse(await fs.readFile(file, 'utf8'));
      if (state.version !== 1 || !state.installed || Array.isArray(state.installed))
        throw new Error('Invalid store state.');
      for (const [id, record] of Object.entries(state.installed)) {
        if (
          !/^[a-z][a-z0-9-]{0,47}--[a-z][a-z0-9-]{0,47}$/.test(id) ||
          record.id !== id ||
          !semver.valid(record.version) ||
          !/^[a-f0-9]{64}$/.test(record.sha256) ||
          typeof record.enabled !== 'boolean' ||
          typeof record.autoUpdate !== 'boolean' ||
          !Array.isArray(record.permissions)
        )
          throw new Error('Invalid installed record.');
        jsonValue(record.settings);
      }
      return state;
    };
    try {
      this.state = await load(path.join(this.directory, 'state.json'));
    } catch (error) {
      try {
        this.state = await load(path.join(this.directory, 'state.json.bak'));
        this.recovery = 'Recovered plugin state from the previous valid backup.';
      } catch (backupError) {
        if (error.code !== 'ENOENT' || backupError.code !== 'ENOENT') throw error;
      }
    }
    if (this.registry) {
      try {
        await this.refresh();
      } catch (error) {
        this.error = error.message;
      }
    }
    return this.snapshot();
  }
  assertTrusted() {
    if (!this.registry) throw new Error('Plugin store is not configured.');
    if (!this.catalog || !(this.registry.validUntil > Date.now())) {
      for (const id of this.workers.keys()) this.stop(id);
      throw new Error('Registry metadata expired or unavailable; refresh required.');
    }
  }
  compatible(manifest) {
    return (
      manifest.platforms.includes(this.platform) &&
      semver.satisfies(this.appVersion, manifest.appVersion)
    );
  }
  release(id, version) {
    this.assertTrusted();
    const release = this.catalog.releases.find(
      (r) => r.manifest.id === id && r.manifest.version === version && r.status === 'approved',
    );
    if (!release || !this.compatible(release.manifest))
      throw new Error('No approved compatible release.');
    return release;
  }
  latest(id) {
    return this.catalog?.releases
      .filter((r) => r.manifest.id === id && r.status === 'approved' && this.compatible(r.manifest))
      .sort((a, b) => semver.rcompare(a.manifest.version, b.manifest.version))[0];
  }
  snapshot() {
    const trusted = !!this.catalog && this.registry?.validUntil > Date.now();
    return {
      configured: !!this.registry,
      trusted,
      error: this.error || null,
      recovery: this.recovery || null,
      validUntil: this.registry?.validUntil || null,
      releases: this.catalog?.releases || [],
      installed: Object.values(this.state.installed).map((record) => {
        const next = this.latest(record.id);
        const update = next && semver.gt(next.manifest.version, record.version) ? next : null;
        return {
          id: record.id,
          version: record.version,
          enabled: record.enabled,
          autoUpdate: record.autoUpdate,
          permissions: record.permissions,
          error: this.errors.get(record.id) || null,
          update,
          requiresConsent: !!update?.manifest.permissions.some(
            (p) => !record.permissions.includes(p),
          ),
        };
      }),
    };
  }
  async save(next, check = () => {}) {
    check();
    const file = path.join(this.directory, 'state.json'),
      temp = file + '.' + randomUUID() + '.tmp';
    try {
      const handle = await fs.open(temp, 'wx', 0o600);
      try {
        await handle.writeFile(JSON.stringify(next));
        await handle.sync();
      } finally {
        await handle.close();
      }
      const backup = temp + '.bak';
      try {
        await fs.writeFile(backup, JSON.stringify(this.state), { mode: 0o600, flag: 'wx' });
        await fs.rename(backup, file + '.bak');
      } finally {
        await fs.unlink(backup).catch(() => {});
      }
      check();
      await fs.rename(temp, file);
      this.state = next;
    } finally {
      await fs.unlink(temp).catch(() => {});
    }
    this.changed();
  }
  async refresh() {
    return this.mutation(async () => {
      if (!this.registry) return this.snapshot();
      try {
        const catalog = await this.registry.refresh();
        const next = structuredClone(this.state);
        for (const record of Object.values(next.installed)) {
          const known = catalog.releases.find((r) => sameRelease(r, record));
          if (!known || known.status !== 'approved') {
            record.enabled = false;
            this.stop(record.id);
            this.errors.set(record.id, known?.status || 'Release no longer approved.');
          }
        }
        this.catalog = catalog;
        this.error = null;
        clearTimeout(this.expiryTimer);
        this.expiryTimer = setTimeout(
          () => {
            this.cancel();
            this.changed();
          },
          Math.max(1, Math.min(2147483647, this.registry.validUntil - Date.now())),
        );
        this.expiryTimer.unref();
        await this.save(next);
        return this.snapshot();
      } catch (error) {
        this.error = error.message;
        this.changed();
        throw error;
      }
    });
  }
  async readPackage(record, release) {
    const file = path.join(this.directory, 'objects', record.sha256 + '.mmxp');
    if ((await fs.stat(file)).size > MAX_PACKAGE_BYTES)
      throw new Error('Installed package integrity failure.');
    const bytes = await fs.readFile(file);
    if (hash(bytes) !== record.sha256 || bytes.length !== release.length)
      throw new Error('Installed package integrity failure.');
    const pkg = decodePackage(bytes);
    if (!isDeepStrictEqual(pkg.manifest, release.manifest))
      throw new Error('Installed manifest integrity failure.');
    return pkg;
  }
  install(id, version, grants, expectedHash) {
    const generation = this.installGenerations.get(id) || 0;
    return this.mutation(() =>
      this.installTransaction(id, version, grants, expectedHash, false, generation),
    );
  }
  async installTransaction(...args) {
    const id = args[0];
    this.installing.add(id);
    try {
      return await this.installCore(...args);
    } finally {
      this.installing.delete(id);
    }
  }
  async installCore(
    id,
    version,
    grants,
    expectedHash,
    automatic = false,
    generation = this.installGenerations.get(id) || 0,
  ) {
    const release = this.release(id, version),
      previous = this.state.installed[id];
    const check = () => {
      if (this.closed || (this.installGenerations.get(id) || 0) !== generation)
        throw new Error('Canceled installation.');
      this.assertTrusted();
      if (
        automatic &&
        (!previous?.enabled ||
          this.enableIntent.get(id) === false ||
          !previous.autoUpdate ||
          this.autoUpdateIntent.get(id) === false ||
          release.manifest.permissions.some((p) => !previous.permissions.includes(p)))
      )
        throw new Error('Automatic update consent no longer applies.');
    };
    check();
    if (expectedHash !== undefined && release.sha256 !== expectedHash)
      throw new Error('Release changed while requesting consent; review again.');
    if (automatic) grants = previous.permissions;
    if (!Array.isArray(grants) || release.manifest.permissions.some((p) => !grants.includes(p)))
      throw new Error('Permission consent required.');
    if (previous && semver.lt(version, previous.version))
      throw new Error('Downgrade is not allowed.');
    if (previous?.version === version && previous.sha256 !== release.sha256)
      throw new Error('Immutable version changed hash.');
    const bytes = await this.registry.download(release);
    check();
    if (hash(bytes) !== release.sha256 || bytes.length !== release.length)
      throw new Error('Downloaded package integrity failure.');
    const pkg = decodePackage(bytes);
    if (!isDeepStrictEqual(pkg.manifest, release.manifest))
      throw new Error('Package manifest differs from approved release.');
    const probe = new PluginProcess(pkg);
    this.probes.set(id, probe);
    const before = structuredClone(this.state);
    let committed = false;
    try {
      const result = await probe.dispatch('activate', { settings: previous?.settings || {} });
      check();
      const record = {
        id,
        version,
        sha256: release.sha256,
        permissions: [...release.manifest.permissions],
        settings: result.settings || previous?.settings || {},
        enabled: previous?.enabled ?? true,
        autoUpdate: previous?.autoUpdate ?? false,
      };
      const file = path.join(this.directory, 'objects', release.sha256 + '.mmxp');
      try {
        await fs.writeFile(file, bytes, { flag: 'wx', mode: 0o600 });
      } catch (error) {
        if (error.code !== 'EEXIST') throw error;
        if (hash(await fs.readFile(file)) !== release.sha256)
          throw new Error('Local object integrity failure.');
      }
      check();
      const next = structuredClone(this.state);
      next.installed[id] = record;
      // No state transition occurs until verification and activation succeeded.
      await this.save(next, check);
      committed = true;
      check();
      this.probes.delete(id);
      this.stop(id);
      this.errors.delete(id);
      this.enableIntent.set(id, record.enabled);
      if (record.enabled) this.workers.set(id, probe);
      else probe.close();
      this.changed();
      return this.snapshot();
    } catch (error) {
      probe.close();
      if (committed) await this.save(before);
      this.errors.set(id, error.message);
      this.changed();
      throw error;
    } finally {
      if (this.probes.get(id) === probe) this.probes.delete(id);
    }
  }
  setEnabled(id, enabled) {
    if (typeof enabled === 'boolean' && Object.hasOwn(this.state.installed, id))
      this.enableIntent.set(id, enabled);
    if (enabled === false) this.stop(id);
    return this.mutation(async () => {
      if (typeof enabled !== 'boolean' || !Object.hasOwn(this.state.installed, id))
        throw new Error('Invalid installed plugin.');
      if (enabled) {
        const record = this.state.installed[id],
          release = this.release(id, record.version);
        if (!sameRelease(release, record)) throw new Error('Installed version no longer approved.');
      }
      const next = structuredClone(this.state);
      next.installed[id].enabled = enabled;
      await this.save(next);
      if (!enabled) this.stop(id);
      this.errors.delete(id);
      return this.snapshot();
    });
  }
  setAutoUpdate(id, enabled) {
    if (typeof enabled === 'boolean') this.autoUpdateIntent.set(id, enabled);
    if (enabled === false) this.cancelInstall(id);
    return this.mutation(async () => {
      if (typeof enabled !== 'boolean' || !Object.hasOwn(this.state.installed, id))
        throw new Error('Invalid installed plugin.');
      const next = structuredClone(this.state);
      next.installed[id].autoUpdate = enabled;
      await this.save(next);
      return this.snapshot();
    });
  }
  uninstall(id) {
    this.enableIntent.set(id, false);
    this.stop(id);
    return this.mutation(async () => {
      if (!Object.hasOwn(this.state.installed, id)) throw new Error('Plugin not installed.');
      const next = structuredClone(this.state);
      delete next.installed[id];
      await this.save(next);
      this.stop(id);
      this.errors.delete(id);
      return this.snapshot();
    });
  }
  updateAutomatic() {
    return this.mutation(async () => {
      this.assertTrusted();
      for (const record of Object.values(this.state.installed)) {
        const release = this.latest(record.id);
        if (
          record.autoUpdate &&
          this.autoUpdateIntent.get(record.id) !== false &&
          this.enableIntent.get(record.id) !== false &&
          record.enabled &&
          release &&
          semver.gt(release.manifest.version, record.version) &&
          release.manifest.permissions.every((p) => record.permissions.includes(p))
        ) {
          try {
            await this.installTransaction(
              record.id,
              release.manifest.version,
              record.permissions,
              release.sha256,
              true,
            );
          } catch (error) {
            this.errors.set(record.id, error.message);
          }
        }
      }
      return this.snapshot();
    });
  }
  execute(id, actionId, payload = {}, signal, event = 'execute') {
    const generation = this.generations.get(id) || 0;
    return this.mutation(async () => {
      const check = () => {
        if (this.closed || signal?.aborted || (this.generations.get(id) || 0) !== generation)
          throw new Error('Canceled.');
        this.assertTrusted();
      };
      check();
      const record = this.state.installed[id];
      if (!record?.enabled) throw new Error('Plugin is disabled or not installed.');
      const release = this.release(id, record.version);
      if (!sameRelease(release, record)) throw new Error('Installed version is not approved.');
      if (!release.manifest.actions.some((a) => a.id === actionId))
        throw new Error('Unknown action.');
      const pkg = await this.readPackage(record, release);
      check();
      let worker = this.workers.get(id);
      try {
        if (!worker) {
          worker = new PluginProcess(pkg);
          this.workers.set(id, worker);
          const activation = await worker.dispatch(
            'activate',
            { settings: record.settings },
            signal,
          );
          check();
          await this.persistSettings(id, activation.settings, check);
        }
        const result = await worker.dispatch(
          event,
          { ...jsonValue(payload), actionId, settings: this.state.installed[id].settings },
          signal,
        );
        check();
        await this.persistSettings(id, result.settings, check);
        check();
        if (result.display && typeof payload.keyId === 'string')
          this.onDisplay(id, payload.keyId, result.display);
        this.errors.delete(id);
        return { message: result.messages.join('\n') || 'Plugin action completed.' };
      } catch (error) {
        this.stop(id);
        this.errors.set(id, error.message);
        this.changed();
        throw error;
      }
    });
  }
  async persistSettings(id, settings, check) {
    if (settings === undefined) return;
    const before = structuredClone(this.state),
      next = structuredClone(this.state);
    next.installed[id].settings = settings;
    await this.save(next, check);
    try {
      check();
    } catch (error) {
      await this.save(before);
      throw error;
    }
  }
  cancelInstall(id) {
    this.installGenerations.set(id, (this.installGenerations.get(id) || 0) + 1);
    this.probes.get(id)?.close();
    this.probes.delete(id);
  }
  stop(id) {
    this.cancelInstall(id);
    this.generations.set(id, (this.generations.get(id) || 0) + 1);
    this.workers.get(id)?.close();
    this.workers.delete(id);
    this.onDisplay(id, null, null);
  }
  cancel() {
    for (const id of new Set([
      ...Object.keys(this.state.installed),
      ...this.workers.keys(),
      ...this.probes.keys(),
      ...this.installing,
    ]))
      this.stop(id);
  }
  close() {
    this.closed = true;
    clearTimeout(this.expiryTimer);
    this.cancel();
  }
}
