import { getQuickJS } from 'quickjs-emscripten';
import { jsonValue } from '@macromaxx/plugin-sdk/contracts';
import { validateOutput } from './output.js';

// No host function, module loader, filesystem, fetch or Node object is exposed.
export class Guest {
  static async create(pkg) {
    const module = await getQuickJS();
    const runtime = module.newRuntime();
    runtime.setMemoryLimit(16 * 1024 * 1024);
    runtime.setMaxStackSize(256 * 1024);
    const guest = new Guest();
    Object.assign(guest, { pkg, runtime, context: runtime.newContext() });
    runtime.setInterruptHandler(() => Date.now() > guest.deadline);
    guest.deadline = Date.now() + 2000;
    try {
      guest.evaluate(pkg.code);
      guest.evaluate(`if (typeof __pluginModule !== 'object' || !__pluginModule.default || !__pluginModule.default.actions) throw Error('Missing plugin definition');
        for (const id of ${JSON.stringify(pkg.manifest.actions.map((a) => a.id))}) if (typeof __pluginModule.default.actions[id]?.execute !== 'function') throw Error('Missing action handler');`);
      return guest;
    } catch (error) {
      guest.close();
      throw error;
    }
  }
  evaluate(code, read = false) {
    const result = this.context.evalCode(code, 'plugin.js', { type: 'global' });
    if (result.error) {
      const error = this.context.dump(result.error);
      result.error.dispose();
      throw new Error(
        typeof error?.message === 'string'
          ? error.message.slice(0, 1000)
          : 'Plugin execution failed.',
      );
    }
    // dump() consumes Promise handles. Do not inspect arbitrary guest values.
    const value = read ? this.context.dump(result.value) : undefined;
    if (result.value.alive) result.value.dispose();
    return value;
  }
  dispatch(event, payload) {
    this.deadline = Date.now() + 2000;
    const permissions = this.pkg.manifest.permissions;
    const input = jsonValue(
      {
        event,
        platform: process.platform,
        permissions,
        payload: {
          ...payload,
          settings: permissions.includes('settings:read') ? payload.settings || {} : {},
        },
      },
      128 * 1024,
    );
    this.evaluate(`var __result = null;
      (async function(input) {
        const out = { messages: [] };
        const copy = x => JSON.parse(JSON.stringify(x));
        const need = p => { if (!input.permissions.includes(p)) throw Error('Missing permission: ' + p); };
        let settings = copy(input.payload.settings);
        const api = Object.freeze({ protocolVersion: 1, platform: input.platform, permissions: Object.freeze(input.permissions),
          settings: Object.freeze({ get() { need('settings:read'); return copy(settings); }, set(value) { need('settings:write'); settings = copy(value); out.settings = settings; } }),
          display: Object.freeze({ set(value) { need('display:write'); out.display = copy(value); } }),
          log(message) { if (out.messages.length >= 20 || typeof message !== 'string' || message.length > 1000) throw Error('Log quota exceeded'); out.messages.push(message); }
        });
        const plugin = __pluginModule.default;
        if (input.event === 'activate' || input.event === 'deactivate') { if (plugin[input.event]) await plugin[input.event](api); }
        else {
          const action = plugin.actions[input.payload.actionId];
          if (!action || !${JSON.stringify(this.pkg.manifest.actions.map((a) => a.id))}.includes(input.payload.actionId)) throw Error('Unknown action');
          const handler = action[input.event];
          if (handler) await handler(Object.freeze({actionId: input.payload.actionId, config: input.payload.config || {}, keyId: input.payload.keyId || '', long: !!input.payload.long}), api);
        }
        return out;
      })(${JSON.stringify(input)}).then(value => { __result = JSON.stringify({ok:value}); }, error => { __result = JSON.stringify({error:String(error?.message || error).slice(0,1000)}); });`);
    while (true) {
      const serialized = this.evaluate('typeof __result === "string" ? __result : null', true);
      if (serialized !== null) {
        if (Buffer.byteLength(serialized) > 70 * 1024) throw new Error('Output quota exceeded.');
        const value = JSON.parse(serialized);
        if (value.error) throw new Error(String(value.error));
        return validateOutput(value.ok, permissions);
      }
      if (Date.now() > this.deadline) throw new Error('Plugin deadline exceeded.');
      const jobs = this.runtime.executePendingJobs(10);
      if (jobs.error) {
        const error = this.context.dump(jobs.error);
        jobs.error.dispose();
        throw new Error(error?.message || 'Plugin job failed.');
      }
      if (jobs.value === 0) throw new Error('Plugin promise did not settle.');
    }
  }
  close() {
    this.context.dispose();
    this.runtime.dispose();
  }
}
