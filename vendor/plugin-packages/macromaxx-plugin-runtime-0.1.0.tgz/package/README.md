# MacroMaxx plugin runtime

Renderer-free QuickJS/WebAssembly execution with a separate supervised Node host process for each active plugin. The guest receives only JSON. There are no host callbacks/import hooks or Node APIs in the guest. Pure guest APIs produce results; the parent checks permissions, quotas and schemas again before persisting settings or updating a key.

**This is not an OS sandbox for a compromised host process.** QuickJS, Emscripten, WebAssembly and Node remain security dependencies. Keep them patched; audit before broad third-party distribution. `node:vm`, ordinary workers and Node's Permission Model are not used as claims of hostile-code isolation. Native bundled providers and legacy plugins still have their old trust boundary.

## Development and tests

Use Node `^22.22.2 || ^24.15.0 || >=26`. In the requested sibling layout:

```sh
npm ci --ignore-scripts
npm test
```

Integration tests use the sibling registry's official TUF models to create ephemeral repositories, and loopback HTTP fixtures. No production keys/endpoints are used. HTTP is forbidden except explicitly enabled loopback developer fixtures. Redirects for registry metadata/targets are rejected.

Exports: `PluginProcess`, `PluginStore`, `TrustedRegistry`.

`PluginProcess.dispatch(event, payload, signal)` returns validated `{messages, display?, settings?}`. `close()` immediately kills the worker. `PluginStore` serializes mutations/events, checks compatibility, consent and current trusted approval, rehashes local objects before execution and applies side effects only to the invoking plugin/key.

## Trust and recovery

TUF root is supplied by the application publisher. The official `tuf-js` updater verifies root rotation, signatures, metadata expiry and rollback protection. A catalog and every package are authenticated targets. SHA-256 and byte length are also compared to the reviewed release. The updater's private DownloadHTTPError import is intentionally version-pinned for 404 handling; test this boundary when upgrading tuf-js.

No successful registry refresh after startup means no store plugin execution. A still-valid catalog can be used during a transient refresh failure, until the **earliest** metadata/catalog expiry. Expiry stops workers. Known revoked/missing/non-approved installations are disabled on refresh; revoked releases cannot be installed or used for rollback. Offline clients cannot learn a new revocation immediately. A wrong system clock and local user-account compromise are outside this layer's guarantees.

Objects are retained by hash; installation verifies and probes activation before atomic pointer replacement. An error before pointer commit leaves the old installation/settings. State writes are private and serialized; the prior JSON is retained as `state.json.bak` and used if the primary is damaged. Corruption of both files requires operator recovery and disables the store without stopping native app features. Power-loss durability is best-effort filesystem durability, not a distributed transaction; hash failures block execution. Old objects are intentionally retained for diagnosis, not automatically executed as a fallback. Uninstall removes the pointer/settings, not saved key assignments or retained package bytes.

Automatic updates are **opt-in**, approved/compatible only, monotonic versions and no additional permissions. Manual installation uses native Electron confirmation bound to the package hash. No shell, network, arbitrary UI or filesystem permission is implemented in v1; privileged runtimes are rejected rather than controlled by cosmetic dialogs.

## Packaging

App `npm run vendor:plugins` makes local package tarballs and snapshots for the registry/example. `npm install --ignore-scripts vendor/plugin-packages/*.tgz` refreshes the app lockfile. Installers use these tarballs, not sibling symlinks. The worker and WASM dependency closure must be unpacked from ASAR. The supervisor translates `app.asar` to `app.asar.unpacked` for the worker entry. Validate actual installers on every target OS; a Linux Node test is not a Windows/macOS packaged-runtime test.
